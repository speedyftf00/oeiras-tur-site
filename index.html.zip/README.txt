OEIRASTUR

Estrutura:
- index.html = site principal
- img/ = pasta para imagens locais (se você baixar as fotos depois)

Por enquanto, as fotos estão usando URLs diretas de fontes públicas. Para deixar o site 100% independente de sites externos, baixe as imagens e coloque-as em img/ e troque os links no HTML por caminhos como img/catedral.jpg.
